import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'pokeZone';
  constructor( public translate: TranslateService) {
    translate.addLangs(['en', 'es', 'ca']);
    translate.setDefaultLang('en');
  }
  //Funció per canviar l'idioma
  switchLang(lang: string) {
    this.translate.use(lang);
  }
}
