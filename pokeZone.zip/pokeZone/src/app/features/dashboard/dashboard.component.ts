import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../core/services/auth.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router, public translate: TranslateService) { 
    translate.addLangs(['en', 'es', 'ca']);
    translate.setDefaultLang('en');
  }

  //Funció per canviar l'idioma
  switchLang(lang: string) {
    this.translate.use(lang);
  }

  ngOnInit(): void {
  }

  logout() {
    this.authService
      .logout()
      .then(() => this.router.navigate(['/']))
      .catch((e) => console.log(e.message));
  }
}