import { Component, OnInit } from '@angular/core';

import { AuthService } from '../../../../core/services/auth.service';
import { LoginData } from 'src/app/core/interfaces/login-data.interface';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.scss'],
})
export class RegisterPageComponent implements OnInit {
  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
    public translate: TranslateService
  ) {
    translate.addLangs(['en', 'es', 'ca']);
    translate.setDefaultLang('en');
  }

  //Funció per canviar l'idioma
  switchLang(lang: string) {
    this.translate.use(lang);
  }

  ngOnInit(): void {}

  register(data: LoginData) {
    this.authService
      .register(data)
      .then(() => this.router.navigate(['/']))
      .catch((e) => console.log(e.message));
  }

  // Informació sobre l'API del reCAPTCHA.
  // Se ha registrado "register".
  // Usa esta clave de sitio web en el código HTML que tu sitio web sirve a los usuarios.
    // <div class="g-recaptcha" data-sitekey="6LfHUTwgAAAAAFUe55qSkSclZoPMqqi35XImoejk"></div>
  // Usa esta clave secreta para la comunicación entre tu sitio web y el servicio reCAPTCHA.
    // 6LfHUTwgAAAAAGxCatxOKOSzvDFLduxs0dTDZi2p

}